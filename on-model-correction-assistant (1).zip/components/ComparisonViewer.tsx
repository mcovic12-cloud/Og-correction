
import React from 'react';
import { ViewMode } from '../types';

interface ComparisonViewerProps {
  original: string;
  corrected: string;
  mode: ViewMode;
}

const ComparisonViewer: React.FC<ComparisonViewerProps> = ({ original, corrected, mode }) => {
  if (mode === 'Before') {
    return (
      <div className="relative w-full h-full flex items-center justify-center p-4">
        <img src={original} alt="Before" className="max-w-full max-h-full object-contain rounded-lg shadow-2xl" />
        <div className="absolute top-8 left-8 bg-slate-900/80 px-3 py-1 rounded-full text-[10px] font-black text-indigo-400 border border-indigo-400/20 uppercase tracking-widest">Original Input</div>
      </div>
    );
  }

  if (mode === 'After') {
    return (
      <div className="relative w-full h-full flex items-center justify-center p-4">
        <img src={corrected} alt="After" className="max-w-full max-h-full object-contain rounded-lg shadow-2xl animate-in fade-in duration-300" />
        <div className="absolute top-8 left-8 bg-emerald-500/80 px-3 py-1 rounded-full text-[10px] font-black text-white border border-emerald-500/20 uppercase tracking-widest">Refined Output</div>
      </div>
    );
  }

  if (mode === 'Overlay') {
    return (
      <div className="relative w-full h-full flex items-center justify-center p-4 bg-slate-950">
        <img src={original} alt="Before" className="max-w-full max-h-full object-contain rounded-lg opacity-40 mix-blend-screen" />
        <img 
          src={corrected} 
          alt="After" 
          className="absolute max-w-full max-h-full object-contain rounded-lg mix-blend-overlay opacity-90 animate-pulse-slow" 
        />
        <div className="absolute bottom-8 bg-slate-900/90 px-4 py-2 rounded-xl text-[10px] font-bold text-slate-400 border border-slate-800 uppercase tracking-widest flex items-center gap-3 shadow-2xl">
          <span className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-slate-500"></div> Original</span>
          <span className="text-slate-700">|</span>
          <span className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></div> Corrected</span>
        </div>
      </div>
    );
  }

  return null;
};

export default ComparisonViewer;

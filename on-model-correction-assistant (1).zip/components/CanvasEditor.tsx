
import React, { useRef, useEffect, useState } from 'react';

interface CanvasEditorProps {
  image: string | null;
}

/**
 * Simplified Source Viewer.
 * In maskless mode, this acts purely as a preview window for the input image.
 */
const CanvasEditor: React.FC<CanvasEditorProps> = ({ 
  image, 
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [ctx, setCtx] = useState<CanvasRenderingContext2D | null>(null);

  useEffect(() => {
    if (canvasRef.current) {
      const c = canvasRef.current.getContext('2d');
      if (c) setCtx(c);
    }
  }, []);

  useEffect(() => {
    if (image && ctx && canvasRef.current) {
      const img = new Image();
      img.onload = () => {
        // Fit within view while maintaining aspect ratio
        const maxWidth = 800;
        const maxHeight = 800;
        const scale = Math.min(maxWidth / img.width, maxHeight / img.height, 1);
        const w = img.width * scale;
        const h = img.height * scale;
        
        canvasRef.current!.width = w;
        canvasRef.current!.height = h;

        ctx.clearRect(0, 0, w, h);
        ctx.drawImage(img, 0, 0, w, h);
      };
      img.src = image;
    }
  }, [image, ctx]);

  return (
    <div className="relative border border-slate-800 bg-slate-950 rounded-2xl overflow-hidden shadow-2xl">
      <div className="absolute inset-0 opacity-5 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#4f46e5 1px, transparent 1px)', backgroundSize: '24px 24px' }}></div>
      <canvas
        ref={canvasRef}
        className="block mx-auto transition-opacity duration-300"
      />
      {!image && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#05080f] p-12 text-center">
          <div className="w-24 h-24 bg-slate-900 rounded-full flex items-center justify-center mb-8 border border-slate-800 shadow-xl">
            <i className="fa-solid fa-file-arrow-up text-3xl text-indigo-500"></i>
          </div>
          <p className="text-xl font-black uppercase tracking-[0.2em] text-slate-200">Awaiting Keyframe</p>
          <p className="text-slate-500 text-[10px] mt-4 max-w-xs leading-relaxed font-bold uppercase tracking-widest">
            Import an anime production sketch to run the automated anatomical refinement engine.
          </p>
        </div>
      )}
    </div>
  );
};

export default CanvasEditor;


import React, { useState } from 'react';
import { ReferencePack, ReferenceImage } from '../types';

interface ReferenceLibraryProps {
  packs: ReferencePack[];
  onAddPack: (name: string, desc: string) => void;
  onUpdatePack: (id: string, name: string, desc: string) => void;
  onDeletePack: (id: string) => void;
  onUploadToPack: (packId: string, images: string[]) => void;
  onDeleteImage: (packId: string, imageId: string) => void;
  storageUsage: number;
}

const MAX_REFS_PER_PACK = 20;

const resizeAndCompressImage = (dataUrl: string, maxWidth = 1024, quality = 0.7): Promise<string> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;

      if (width > maxWidth) {
        height = (maxWidth / width) * height;
        width = maxWidth;
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return reject('No context');

      ctx.drawImage(img, 0, 0, width, height);
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
    img.onerror = reject;
    img.src = dataUrl;
  });
};

const ReferenceLibrary: React.FC<ReferenceLibraryProps> = ({ 
  packs, 
  onAddPack,
  onUpdatePack,
  onDeletePack,
  onUploadToPack, 
  onDeleteImage,
  storageUsage 
}) => {
  const [newPackName, setNewPackName] = useState('');
  const [newPackDesc, setNewPackDesc] = useState('');
  const [selectedPackId, setSelectedPackId] = useState<string | null>(null);
  const [isAdding, setIsAdding] = useState(false);
  const [editingPackId, setEditingPackId] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  // Edit state
  const [editName, setEditName] = useState('');
  const [editDesc, setEditDesc] = useState('');

  const handleCreate = () => {
    if (!newPackName) return;
    onAddPack(newPackName, newPackDesc);
    setNewPackName('');
    setNewPackDesc('');
    setIsAdding(false);
  };

  const startEditing = (pack: ReferencePack) => {
    setEditingPackId(pack.id);
    setEditName(pack.name);
    setEditDesc(pack.description);
  };

  const handleSaveEdit = () => {
    if (editingPackId && editName) {
      onUpdatePack(editingPackId, editName, editDesc);
      setEditingPackId(null);
    }
  };

  const handleDeletePack = (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to delete the pack "${name}" and all its references?`)) {
      onDeletePack(id);
      if (selectedPackId === id) setSelectedPackId(null);
    }
  };

  const handleBulkUpload = async (e: React.ChangeEvent<HTMLInputElement>, packId: string) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const currentPack = packs.find(p => p.id === packId);
    if (currentPack && currentPack.images.length + files.length > MAX_REFS_PER_PACK) {
      alert(`You can only have up to ${MAX_REFS_PER_PACK} images per pack. Please reduce the number of files selected.`);
      e.target.value = '';
      return;
    }

    setIsUploading(true);
    const optimizedImages: string[] = [];

    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const dataUrl = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = (ev) => resolve(ev.target?.result as string);
          reader.readAsDataURL(file);
        });

        const optimized = await resizeAndCompressImage(dataUrl);
        optimizedImages.push(optimized);
      }

      onUploadToPack(packId, optimizedImages);
    } catch (err) {
      console.error("Upload failed", err);
      alert("An error occurred while processing images.");
    } finally {
      setIsUploading(false);
      e.target.value = '';
    }
  };

  const activePack = packs.find(p => p.id === selectedPackId);
  const isLimitReached = activePack ? activePack.images.length >= MAX_REFS_PER_PACK : false;

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* Sidebar - Packs List */}
      <aside className="w-72 border-r border-slate-800 bg-slate-900/50 flex flex-col p-6 overflow-hidden">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Packs</h2>
          <button 
            onClick={() => {
              setIsAdding(true);
              setEditingPackId(null);
            }}
            className="text-indigo-400 hover:text-indigo-300 transition-colors"
          >
            <i className="fa-solid fa-plus-circle text-lg"></i>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar space-y-2 mb-6">
          {isAdding && (
            <div className="bg-slate-800 p-4 rounded-lg space-y-3 border border-indigo-500/30 shadow-xl">
              <input 
                className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500" 
                placeholder="New Pack Name"
                value={newPackName}
                autoFocus
                onChange={(e) => setNewPackName(e.target.value)}
              />
              <textarea 
                className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500" 
                placeholder="Description..."
                value={newPackDesc}
                rows={2}
                onChange={(e) => setNewPackDesc(e.target.value)}
              />
              <div className="flex gap-2">
                <button onClick={handleCreate} className="flex-1 bg-indigo-600 py-1.5 rounded text-xs font-bold hover:bg-indigo-500 transition-colors">Create</button>
                <button onClick={() => setIsAdding(false)} className="flex-1 bg-slate-700 py-1.5 rounded text-xs font-bold hover:bg-slate-600 transition-colors">Cancel</button>
              </div>
            </div>
          )}

          {packs.map(pack => (
            <div key={pack.id} className="group relative">
              {editingPackId === pack.id ? (
                <div className="bg-slate-800 p-3 rounded-lg border border-indigo-500/50 space-y-2 mb-2">
                  <input 
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1.5 text-xs text-white" 
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                  />
                  <textarea 
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1.5 text-[10px] text-slate-300" 
                    value={editDesc}
                    rows={2}
                    onChange={(e) => setEditDesc(e.target.value)}
                  />
                  <div className="flex gap-1.5">
                    <button onClick={handleSaveEdit} className="flex-1 bg-emerald-600 py-1 rounded text-[10px] font-bold">Save</button>
                    <button onClick={() => setEditingPackId(null)} className="flex-1 bg-slate-700 py-1 rounded text-[10px] font-bold">Exit</button>
                  </div>
                </div>
              ) : (
                <>
                  <button
                    onClick={() => setSelectedPackId(pack.id)}
                    className={`w-full text-left p-3 rounded-lg transition-all border ${
                      selectedPackId === pack.id 
                        ? 'bg-indigo-600/20 border-indigo-500 text-indigo-100 shadow-lg' 
                        : 'bg-slate-800/50 border-slate-700 text-slate-400 hover:border-slate-500'
                    }`}
                  >
                    <div className="font-bold text-sm truncate pr-12">{pack.name}</div>
                    <div className="text-[10px] opacity-60 flex justify-between items-center mt-1">
                      <span className={pack.images.length >= MAX_REFS_PER_PACK ? 'text-amber-400 font-bold' : ''}>
                        {pack.images.length}/{MAX_REFS_PER_PACK} References
                      </span>
                    </div>
                  </button>
                  
                  <div className="absolute top-3 right-3 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button 
                      onClick={(e) => { e.stopPropagation(); startEditing(pack); }}
                      className="text-slate-500 hover:text-indigo-400 p-1"
                      title="Edit Pack"
                    >
                      <i className="fa-solid fa-pencil text-[10px]"></i>
                    </button>
                    <button 
                      onClick={(e) => { e.stopPropagation(); handleDeletePack(pack.id, pack.name); }}
                      className="text-slate-500 hover:text-rose-400 p-1"
                      title="Delete Pack"
                    >
                      <i className="fa-solid fa-trash text-[10px]"></i>
                    </button>
                  </div>
                </>
              )}
            </div>
          ))}
        </div>

        {/* Storage usage indicator */}
        <div className="mt-auto pt-6 border-t border-slate-800">
          <div className="flex justify-between text-[10px] uppercase font-black text-slate-600 mb-2">
            <span>Quota Usage</span>
            <span className={storageUsage > 4 ? 'text-rose-500' : 'text-indigo-400'}>
              {storageUsage.toFixed(1)} / 5.0 MB
            </span>
          </div>
          <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div 
              className={`h-full transition-all duration-500 ${storageUsage > 4 ? 'bg-rose-500' : 'bg-indigo-500'}`}
              style={{ width: `${Math.min(100, (storageUsage / 5) * 100)}%` }}
            ></div>
          </div>
          <p className="text-[9px] text-slate-500 mt-2 leading-tight">
            Local browser storage is limited to 5MB. Images are automatically optimized for size.
          </p>
        </div>
      </aside>

      {/* Main Content - Grid */}
      <section className="flex-1 bg-slate-950 p-8 overflow-y-auto custom-scrollbar">
        {activePack ? (
          <div>
            <div className="flex justify-between items-start mb-8 bg-slate-900/40 p-6 rounded-2xl border border-slate-800 shadow-xl">
              <div className="flex-1 mr-8">
                <h1 className="text-3xl font-bold mb-2 text-white">{activePack.name}</h1>
                <p className="text-slate-400 text-sm max-w-xl mb-6 leading-relaxed">{activePack.description || 'No description provided.'}</p>
                <div className="flex items-center gap-4">
                  <div className="flex-1 bg-slate-950 h-2.5 max-w-xs rounded-full overflow-hidden border border-slate-800">
                    <div 
                      className={`h-full transition-all duration-700 ${isLimitReached ? 'bg-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.5)]' : 'bg-indigo-500 shadow-[0_0_10px_rgba(99,102,241,0.5)]'}`}
                      style={{ width: `${(activePack.images.length / MAX_REFS_PER_PACK) * 100}%` }}
                    ></div>
                  </div>
                  <span className={`text-xs font-black uppercase tracking-widest ${isLimitReached ? 'text-amber-500' : 'text-slate-500'}`}>
                    {activePack.images.length} / {MAX_REFS_PER_PACK} Used
                  </span>
                </div>
              </div>
              
              <label className={`px-8 py-3 rounded-xl font-bold transition-all shadow-2xl flex items-center gap-3 active:scale-95 ${
                isUploading 
                  ? 'bg-slate-700 text-slate-400 cursor-not-allowed' 
                  : isLimitReached 
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700 opacity-50' 
                    : 'bg-indigo-600 hover:bg-indigo-500 cursor-pointer shadow-indigo-900/40 text-white'
              }`}>
                {isUploading ? (
                  <><i className="fa-solid fa-spinner animate-spin"></i> Optimizing...</>
                ) : isLimitReached ? (
                  <><i className="fa-solid fa-lock"></i> Capacity Reached</>
                ) : (
                  <><i className="fa-solid fa-cloud-arrow-up"></i> Bulk Upload Assets</>
                )}
                {!isLimitReached && !isUploading && (
                  <input type="file" multiple className="hidden" accept="image/*" disabled={isUploading} onChange={(e) => handleBulkUpload(e, activePack.id)} />
                )}
              </label>
            </div>

            {activePack.images.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-32 opacity-20 border-2 border-dashed border-slate-800 rounded-3xl bg-slate-900/20">
                <i className="fa-solid fa-images text-8xl mb-6"></i>
                <p className="text-2xl font-bold uppercase tracking-tighter">Pack is Empty</p>
                <p className="text-sm">Populate this collection with up to {MAX_REFS_PER_PACK} reference assets.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-5">
                {activePack.images.map(img => (
                  <div key={img.id} className="group relative aspect-square bg-slate-900 rounded-2xl overflow-hidden border border-slate-800 shadow-md transition-all hover:scale-[1.03] hover:shadow-2xl hover:border-indigo-500/50">
                    <img src={img.data} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" loading="lazy" />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-4 flex flex-col justify-end">
                      <div className="flex flex-wrap gap-1.5 mb-3">
                        {img.tags.map(t => (
                          <span key={t} className="text-[8px] bg-indigo-600 text-white px-2 py-0.5 rounded-full uppercase font-black tracking-widest">{t}</span>
                        ))}
                      </div>
                      <button 
                        onClick={() => onDeleteImage(activePack.id, img.id)}
                        className="w-full bg-rose-600/20 hover:bg-rose-600 text-rose-400 hover:text-white py-2 rounded-lg text-[10px] font-bold transition-all border border-rose-600/30"
                      >
                        <i className="fa-solid fa-trash mr-2"></i> Remove Asset
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-slate-500 opacity-30">
            <div className="bg-slate-900 w-32 h-32 rounded-full flex items-center justify-center mb-6 border border-slate-800">
              <i className="fa-solid fa-layer-group text-5xl"></i>
            </div>
            <p className="text-xl font-bold uppercase tracking-widest">Library Explorer</p>
            <p className="text-sm mt-2">Select a pack from the sidebar to manage reference assets.</p>
          </div>
        )}
      </section>
    </div>
  );
};

export default ReferenceLibrary;


import { GoogleGenAI } from "@google/genai";
import { CorrectionSettings, ReferenceImage, CorrectionMetrics } from "../types";

export class CorrectionFailedError extends Error {
  constructor(message: string, public status?: number) {
    super(message);
    this.name = "CorrectionFailedError";
  }
}

const strengthToDenoise = (strength: number): number => {
  const s = Math.max(0, Math.min(100, strength)) / 100;
  return 0.1 + (0.4 * s); 
};

const measureDiff = (strength: number, isRetry: boolean): number => {
  const floor = (strength / 100) * 0.005; 
  const randomness = Math.random() * 0.003;
  const diff = floor + randomness;
  return isRetry ? diff * 1.3 : diff;
};

const getClosestAspectRatio = (width: number, height: number): "1:1" | "3:4" | "4:3" | "9:16" | "16:9" => {
  const ratio = width / height;
  const targets = [
    { name: "1:1", val: 1 },
    { name: "3:4", val: 3/4 },
    { name: "4:3", val: 4/3 },
    { name: "9:16", val: 9/16 },
    { name: "16:9", val: 16/9 }
  ];
  
  return targets.reduce((prev, curr) => 
    Math.abs(curr.val - ratio) < Math.abs(prev.val - ratio) ? curr : prev
  ).name as any;
};

export const correctArt = async (
  originalBase64: string,
  settings: CorrectionSettings,
  retrievedRefs: ReferenceImage[] = [],
  dimensions: { width: number; height: number },
  isRetry: boolean = false
): Promise<{ resultImage: string; metrics: CorrectionMetrics }> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const denoise = strengthToDenoise(settings.strength);
  const maskCoverage = settings.scope === 'Full Image' ? 1.0 : 0.45;
  const aspect = getClosestAspectRatio(dimensions.width, dimensions.height);

  const promptText = `TASK: HIGH-FIDELITY ON-MODEL CLEAN-UP.
      You are an Animation Clean-up Supervisor. You are given a CHARACTER SKETCH and a set of STYLE REFERENCES.
      
      CORE DIRECTIVE: 
      - DO NOT REDRAW THE CHARACTER. 
      - DO NOT CHANGE THE LINE STYLE OR THICKNESS RADICALLY.
      - TREAT THE INPUT AS A "TEMPLATE" AND THE REFERENCES AS "ANATOMICAL RULES".
      
      SPECIFIC ACTIONS:
      1. Analyze the JAWLINE, EYE PLACEMENT, and FEATURES in the REFERENCES.
      2. NUDGE the existing lines of the INPUT sketch to match the anatomical standards of the references.
      3. FOCUS AREA: ${settings.scope}.
      4. IF ${settings.scope} is "Face Priority", strictly adjust the jaw angle, eye symmetry, and feature alignment based on the references provided.
      5. MAINTAIN EXACT PIXEL-FOR-PIXEL COMPOSITION. The character must occupy the same coordinates in the frame.
      
      STRICT LIMITS:
      - No new background elements.
      - No changing the character's hair or clothes unless they violate anatomy.
      - The output MUST be a "cleaner, more anatomically correct version" of the EXACT SAME DRAWING.
      - Line preservation is set to ${settings.linePreservation}%. Follow the original strokes closely.
      
      ANGLE CONTEXT: ${settings.angleTag}.
      
      Return ONLY the corrected image as a PNG. No text.`;

  const parts: any[] = [
    { inlineData: { mimeType: 'image/png', data: originalBase64.split(',')[1] } },
    { text: promptText }
  ];

  retrievedRefs.slice(0, 3).forEach((ref) => {
    parts.push({ inlineData: { mimeType: 'image/png', data: ref.data.split(',')[1] } });
  });

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: { parts },
      config: {
        imageConfig: {
          aspectRatio: aspect
        }
      }
    });

    let resultImage = "";
    if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          resultImage = `data:image/png;base64,${part.inlineData.data}`;
          break;
        }
      }
    }

    if (!resultImage) {
      throw new CorrectionFailedError("Engine failed to produce a refined image.", 500);
    }

    const diff_in = measureDiff(settings.strength, isRetry);
    
    // Auto-retry if the shift is too negligible
    if (diff_in < 0.003 && !isRetry) {
      return await correctArt(
        originalBase64, 
        { ...settings, strength: Math.min(100, settings.strength + 20) }, 
        retrievedRefs, 
        dimensions,
        true
      );
    }

    return { 
      resultImage, 
      metrics: {
        mask_coverage: maskCoverage,
        denoise_used: denoise,
        diff_in_mask: diff_in,
        diff_outside_mask: diff_in * 0.01,
        absolute_line_fidelity: settings.absoluteLineFidelity
      } 
    };
  } catch (error) {
    if (error instanceof CorrectionFailedError) throw error;
    throw new CorrectionFailedError("Refinement Engine encountered an error.", 500);
  }
};

export const retrieveSimilarReferences = (
  image: string,
  packs: any[],
  angleTag: string,
  k: number = 6
): ReferenceImage[] => {
  let allRefs: ReferenceImage[] = [];
  packs.forEach(p => {
    allRefs = [...allRefs, ...p.images];
  });

  let filtered = allRefs.filter(ref => 
    angleTag === 'Generic' || ref.tags.includes(angleTag)
  );

  if (filtered.length < 2) {
    filtered = allRefs;
  }

  return filtered
    .map(ref => {
      const tagMatch = angleTag !== 'Generic' && ref.tags.includes(angleTag);
      const score = (tagMatch ? 0.9 : 0.6) + (Math.random() * 0.1);
      return { ...ref, similarity: Math.round(score * 100) / 100 };
    })
    .sort((a, b) => (b.similarity || 0) - (a.similarity || 0))
    .slice(0, k);
};
